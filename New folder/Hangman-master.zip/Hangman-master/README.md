# Hangman
Simple Hangman Game in Python
This is simple hangman game implemented in python.
it has text file including all the words.
please make sure to keep all the files in one directory or else it will not work.
This game selects any random word from the file and asks you to guess character for that word.
You will get 8 chances to guess a word.
when you guesses correct character your chance will not be counted when you gives wrong character your chance will be reduced by one.

Hope you enjoy this game. 
Any modification in this game would be highly appreciated.
