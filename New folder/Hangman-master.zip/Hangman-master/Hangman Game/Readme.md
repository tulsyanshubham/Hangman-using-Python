When you run this python script it will choose a word from the word.txt file.
it will show you how many characters are there in this word and asks you to enter a character.
you will get 8 chances to guess a right word.
your chance will be decreamented whenever you guess wrong word.

Make sure to put this both file in one directory.
